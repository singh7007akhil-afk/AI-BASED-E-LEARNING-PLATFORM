import os, json, random
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///eduai.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    course_id = db.Column(db.Integer, nullable=False)
    progress = db.Column(db.Integer, default=0)

class Activity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    kind = db.Column(db.String(30), nullable=False)
    score = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

COURSES = [
    {"id": 1, "title": "Python for Beginners", "category": "Programming", "level": "Beginner", "duration": "6 weeks", "lessons": 18, "icon": "🐍", "description": "Learn Python fundamentals, variables, loops, functions and practical projects."},
    {"id": 2, "title": "Web Development Basics", "category": "Web Development", "level": "Beginner", "duration": "5 weeks", "lessons": 15, "icon": "🌐", "description": "Build responsive websites using HTML, CSS and JavaScript."},
    {"id": 3, "title": "Java Programming", "category": "Programming", "level": "Intermediate", "duration": "7 weeks", "lessons": 21, "icon": "☕", "description": "Understand object-oriented programming and core Java concepts."},
    {"id": 4, "title": "Introduction to Machine Learning", "category": "AI & Data", "level": "Intermediate", "duration": "8 weeks", "lessons": 24, "icon": "🤖", "description": "Explore datasets, model training, prediction and evaluation."},
    {"id": 5, "title": "SQL & Database Design", "category": "Database", "level": "Beginner", "duration": "4 weeks", "lessons": 12, "icon": "🗄️", "description": "Learn SQL queries, relationships, joins and database design."},
    {"id": 6, "title": "Data Science Foundations", "category": "AI & Data", "level": "Beginner", "duration": "6 weeks", "lessons": 18, "icon": "📊", "description": "Work with data using Python, Pandas and visualizations."}
]

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def current_user():
    return db.session.get(User, session.get("user_id"))

def ai_response(prompt, system="You are EduAI, a friendly and accurate tutor. Explain in simple language with examples."):
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            result = client.chat.completions.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                temperature=0.6
            )
            return result.choices[0].message.content
        except Exception as exc:
            app.logger.warning("AI provider error: %s", exc)
            return "I couldn't reach the AI service right now. Please check your API key and connection, then try again."
    return ("**Demo AI response**\n\n"
            "I can help you learn this topic. Here is a simple way to approach it:\n\n"
            "1. Start with the basic definition.\n"
            "2. Understand the idea with a small example.\n"
            "3. Practise it yourself and explain it in your own words.\n\n"
            f"Your question was: {prompt}\n\n"
            "To enable real AI-generated answers, add your OpenAI API key to the `.env` file.")

@app.route("/")
def home():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html", courses=COURSES[:3])

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name, a valid email and a password of at least 8 characters.", "error")
        elif User.query.filter_by(email=email).first():
            flash("An account with this email already exists.", "error")
        else:
            user = User(name=name, email=email, password=generate_password_hash(password))
            db.session.add(user); db.session.commit()
            session["user_id"] = user.id
            flash("Welcome to EduAI! Your account is ready.", "success")
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, request.form.get("password", "")):
            session["user_id"] = user.id
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    enrollments = Enrollment.query.filter_by(user_id=user.id).all()
    activities = Activity.query.filter_by(user_id=user.id).order_by(Activity.created_at.desc()).limit(5).all()
    enrolled = []
    for e in enrollments:
        course = next((c for c in COURSES if c["id"] == e.course_id), None)
        if course:
            enrolled.append({**course, "progress": e.progress})
    avg = round(sum(e.progress for e in enrollments) / len(enrollments)) if enrollments else 0
    return render_template("dashboard.html", user=user, courses=COURSES, enrolled=enrolled, activities=activities, avg=avg)

@app.route("/courses")
@login_required
def courses():
    user = current_user()
    enrolled_ids = [e.course_id for e in Enrollment.query.filter_by(user_id=user.id).all()]
    return render_template("courses.html", courses=COURSES, enrolled_ids=enrolled_ids)

@app.route("/enroll/<int:course_id>", methods=["POST"])
@login_required
def enroll(course_id):
    if not any(c["id"] == course_id for c in COURSES):
        return jsonify({"ok": False, "message": "Course not found"}), 404
    existing = Enrollment.query.filter_by(user_id=session["user_id"], course_id=course_id).first()
    if not existing:
        db.session.add(Enrollment(user_id=session["user_id"], course_id=course_id))
        db.session.commit()
    return jsonify({"ok": True, "message": "Course added to your learning list."})

@app.route("/course/<int:course_id>")
@login_required
def course_detail(course_id):
    course = next((c for c in COURSES if c["id"] == course_id), None)
    if not course:
        return redirect(url_for("courses"))
    enrollment = Enrollment.query.filter_by(user_id=session["user_id"], course_id=course_id).first()
    if not enrollment:
        return redirect(url_for("courses"))
    return render_template("course_detail.html", course=course, enrollment=enrollment)

@app.route("/course/<int:course_id>/complete", methods=["POST"])
@login_required
def complete_lesson(course_id):
    enrollment = Enrollment.query.filter_by(user_id=session["user_id"], course_id=course_id).first()
    if not enrollment:
        return jsonify({"ok": False}), 404
    enrollment.progress = min(100, enrollment.progress + 10)
    db.session.add(Activity(user_id=session["user_id"], kind="lesson", score=enrollment.progress))
    db.session.commit()
    return jsonify({"ok": True, "progress": enrollment.progress})

@app.route("/tutor")
@login_required
def tutor():
    return render_template("tutor.html")

@app.route("/api/ask", methods=["POST"])
@login_required
def ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"answer": "Please enter a question."}), 400
    answer = ai_response(question)
    return jsonify({"answer": answer})

@app.route("/quiz")
@login_required
def quiz():
    return render_template("quiz.html")

@app.route("/api/quiz", methods=["POST"])
@login_required
def generate_quiz():
    data = request.get_json(silent=True) or {}
    topic = (data.get("topic") or "Python basics").strip()[:120]
    prompt = ("Create exactly 5 multiple-choice questions about: " + topic +
              ". Return ONLY valid JSON array. Each item must have question, options (array of 4 strings), answer (zero-based integer), explanation.")
    raw = ai_response(prompt, "You create accurate educational multiple-choice quizzes. Return valid JSON only.")
    try:
        start, end = raw.find("["), raw.rfind("]") + 1
        questions = json.loads(raw[start:end])
        if not isinstance(questions, list) or not questions:
            raise ValueError("Invalid quiz")
        return jsonify({"questions": questions[:10], "demo": False})
    except Exception:
        questions = [
            {"question": f"What is the best first step when learning {topic}?", "options": ["Memorize everything", "Understand the fundamentals", "Skip examples", "Avoid practice"], "answer": 1, "explanation": "Strong foundations make advanced topics easier."},
            {"question": "Which approach improves learning most?", "options": ["Active practice", "Only rereading", "Avoiding questions", "Studying without breaks"], "answer": 0, "explanation": "Active practice helps you recall and apply concepts."},
            {"question": "What should you do after making a mistake?", "options": ["Give up", "Ignore it", "Review and learn from it", "Delete your work"], "answer": 2, "explanation": "Mistakes reveal what you need to practise."},
            {"question": "Why are examples useful?", "options": ["They replace learning", "They connect theory to practice", "They make topics harder", "They are never needed"], "answer": 1, "explanation": "Examples show how ideas work in real situations."},
            {"question": "Which is a good revision habit?", "options": ["Never revisit topics", "Practise regularly", "Study only before exams", "Avoid testing yourself"], "answer": 1, "explanation": "Regular practice supports long-term retention."}
        ]
        return jsonify({"questions": questions, "demo": True})

@app.route("/api/quiz-result", methods=["POST"])
@login_required
def quiz_result():
    score = int((request.get_json(silent=True) or {}).get("score", 0))
    score = max(0, min(100, score))
    db.session.add(Activity(user_id=session["user_id"], kind="quiz", score=score))
    db.session.commit()
    return jsonify({"ok": True})

@app.route("/notes")
@login_required
def notes():
    return render_template("notes.html")

@app.route("/api/notes", methods=["POST"])
@login_required
def make_notes():
    data = request.get_json(silent=True) or {}
    topic = (data.get("topic") or "").strip()
    if not topic:
        return jsonify({"notes": "Please enter a topic."}), 400
    notes_text = ai_response("Create clear, structured study notes with headings, key points and one example about: " + topic,
                             "You are an expert study-notes creator. Use simple language and concise formatting.")
    return jsonify({"notes": notes_text})

@app.route("/progress")
@login_required
def progress():
    user = current_user()
    enrollments = Enrollment.query.filter_by(user_id=user.id).all()
    activities = Activity.query.filter_by(user_id=user.id).order_by(Activity.created_at.desc()).all()
    return render_template("progress.html", enrollments=enrollments, courses=COURSES, activities=activities)

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)
