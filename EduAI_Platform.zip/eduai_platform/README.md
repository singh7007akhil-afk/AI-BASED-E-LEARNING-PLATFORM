# EduAI – AI-Powered E-Learning Platform

A beginner-friendly full-stack e-learning project built with HTML, CSS, JavaScript, Python Flask and SQLite.

## Features
- Student registration, login and logout
- Student dashboard
- Course catalogue and course enrollment
- Lesson progress tracking
- AI tutor chat
- AI quiz generator with a demo fallback
- AI study-notes generator
- Learning activity history

## Requirements
- Python 3.10+
- An internet connection for installing packages and using the live AI service
- An OpenAI API key for live AI responses (optional for local demo)

## Setup (Windows / Anaconda Prompt)
1. Extract the ZIP and open the `eduai_platform` folder in VS Code.
2. Create and activate an environment:
   ```bash
   conda create -n eduai python=3.11 -y
   conda activate eduai
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env`.
   - Set a long random `SECRET_KEY`.
   - Add your OpenAI API key to `OPENAI_API_KEY` to enable live AI.
   - Leave the key blank to use demo responses.
5. Start Flask:
   ```bash
   python app.py
   ```
6. Open http://127.0.0.1:5000 in your browser.
7. Register a new account and explore the platform.

## Project structure
```text
eduai_platform/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── auth.html
│   ├── dashboard.html
│   ├── courses.html
│   ├── course_detail.html
│   ├── tutor.html
│   ├── quiz.html
│   ├── notes.html
│   └── progress.html
└── static/
    ├── css/style.css
    └── js/app.js
```

## Important notes
- The app creates its SQLite database automatically on first run.
- The included courses are sample course records; replace or expand them for your project.
- The no-key mode is a demonstration fallback, not a real AI model.
- Never commit `.env` or publish your API key.
- Before production deployment, disable Flask debug mode, use a production WSGI server, set secure cookie settings, add CSRF protection, rate limiting and proper API usage controls.
